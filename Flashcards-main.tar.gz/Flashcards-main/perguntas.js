criaCartao(
    'Astronomia',
    'O que é gravidade?',
    'De acordo com a relatividade geral, é a deformação do espaço tempo causado por um objeto massivo como uma estrela ou um planeta, por exemplo'
)

criaCartao(
    'Biologia',
    'O que é câncer?',
    'É o crescimento desordenado das células devido a alterações no mecanismo celular'
)

criaCartao(
    'Geografia',
    'Qual a capital da Austrália?',
    'Camberra'
)

criaCartao(
    'Inglês',
    'Como se diz mar em inglês?',
    'Sea'
)

criaCartao(
    'Matemática',
    'Qual é a raiz quadrada de -4?',
    'É mais ou menos 2i'
)

criaCartao(
    'Química',
    'O que significa densidade?',
    'É quanto determinada massa de um elemento ocupa certo espaço'
)

criaCartao(
    'Física',
    'Por qual descoberta Albert Einstein ganhou o prêmio nobel de física?',
    'Efeito fotoelétrico'
)

